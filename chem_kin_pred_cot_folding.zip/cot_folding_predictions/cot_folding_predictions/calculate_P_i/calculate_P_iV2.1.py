#Version Information: 07/03/2015
#Python implementation of Ed O'Brien et al. Nat. Commun. 3, 868, (2012) Eq. 6
#Calculates the probability of folding for a nascent chain as a function of chain length 
#This script calculates the values of P_FB(i) via Eq. 2 of this manuscript; Eq. 16 takes these values as inputs

#Example command
#> python calculate_P_i.py k_A k_F k_U domain_length protein_length_with_stop_codon_included  > 1_FRB_rand_p_i.out
#> python ../general_calculate_P_i.py 3.9 20.0 4.34E-05 267 1257 codon_trans_rates_file run_number > SFVP_rand.out

#import modules for computation
from numpy import* 
import sys
import os
import random

def get_input(line):
        x = line.split("=")
        y = x[1]
        y = y.rstrip('\n')
        return y

#codon_rates = loadtxt(str(sys.argv[1]), dtype='str')
f_mRNA_seq = str(sys.argv[1])
k_F = float(sys.argv[2])
k_U = float(sys.argv[3])
domain_length=int(sys.argv[4])
protein_length =int( sys.argv[5])
f_codon_rates = loadtxt(sys.argv[6], dtype='str')
run_num = int(sys.argv[7])

fileHandle = open(f_mRNA_seq, 'r')
mRNA_sequence = fileHandle.read()
fileHandle.close()

codon = f_codon_rates[:,0]

codon_trans_rate = f_codon_rates[:,1]

#define custom for loop that doesn't skip values
def my_range(start, end, increment):
    while start <= end:
        yield start
        start+= increment

A = zeros((protein_length, 1))
F = zeros((len(A), 1)) 
U = zeros((len(A), 1)) 

#make a dictionary to relate codons to their translation rates
codon_rate_dict = {}

#populate dictionary
for z in range (0, len(codon)):
        codon_rate_dict[codon[z]] = codon_trans_rate[z]
        #keyed by codon string; returns corresponding translation rate

#parse mRNA sequence into codons
codon_trans_rates = zeros((len(mRNA_sequence)/3, 1))

#match codons to translation rates
for nc in range (0, len(mRNA_sequence)-2,3):
        codon_temp =  str(mRNA_sequence[nc]+mRNA_sequence[nc+1]+mRNA_sequence[nc+2])
        i = (nc+3)/3
        codon_trans_rates[i-1] = codon_rate_dict[codon_temp]

for value in range(0, len(A)):
    U[value] =  k_U #hard-coded unfolding rate in unites of s^-1
    A[value] =  codon_trans_rates[value]# can potentially hard-code a uniform translation rate
    if value >= (domain_length + 29): #the 29 value allows for the steric effect of the ribosome exit tunnel
       F[value] = k_F  #hard-coded folding rate in units of s^-1

n = int(len(A)-1)

#compute the values of P as a function of i for each of the possible nascent chain lengths 
for i in my_range (0, n-1, 1): #for each i
    P = 0.0000 #initialize P, the probability of folding
    prod = 0.0000 #initialize prod, which is equivalent to product (pi) term from Eq. 2
    for j in my_range(0, i, 1): # we need j from 0 to i
        for k in my_range(j, i, 1): # and we need k from j to i
            #print i, j, k
            if k == j: #when k == j we have a special case
                    prod = A[k+1]/(A[k+1]+F[k]+U[k])      
            else: #otherwise,
                prod = prod*(A[k+1]/(A[k+1]+F[k]+U[k]))            
        #print i, j, k, '%.20f' %prod 
        P+=(F[j]/A[j+1])*prod  
    print i+1,'\t','%.9f' %P 

with open('cntrl_files/'+str(run_num) + '_pulse-chase.cntrl', "a") as log:
        log.write('f_mrna_sequence='+f_mRNA_seq+'\n')
        log.write('f_codon_rates=input_files/'+str(run_num)+'_rates_for_SFVP'+'\n')
        log.write('f_pfi=input_files/'+str(run_num)+'_p_i.txt'+'\n')
        log.write('region_of_interest='+str(sys.argv[4])+ '\n')
        log.write('rate_of_unfolding='+str(float(k_U))+'\n')
        log.write('rate_of_folding='+str(float(k_F))+'\n')
        log.write('domain_start_codon=1'+'\n')
        log.write('pulse_time=45'+'\n')
        log.write('chase_time=360'+'\n')
        log.write('incorporation_time_offset=10'+'\n')

for value in range (0, 63):
        with open('input_files/'+str(run_num)+'_rates_for_SFVP', "a") as log:
                log.write(str(codon[value])+'\t'+str(float(codon_trans_rate[value]))+'\n')
