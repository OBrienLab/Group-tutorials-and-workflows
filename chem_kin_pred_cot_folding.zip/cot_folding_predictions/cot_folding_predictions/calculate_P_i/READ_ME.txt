This directory contains a python script, "calculate_P_i.py" that implements Eq. 2 of the 
main text to generate a set of co-translational folding probabilities as a function of
nascent chain length. This script is easiest to run in a python interpreter such as
Spyder, and also requires the numpy "number python" module.

The script "calculate_pulse-chase_cot_folding_curve.pl" takes as an input the output
of the "calculate_P_i.py" and/or "calculate_P_iV2.1.py" scripts. "calculate_P_iV2.1.py"
differs from "calculate_P_i.py" in that it requires an mRNA sequence be read in; this is
necessary for the yeast proteins and for some of the calculations with SFVP_delta-c.

Example input files for the calculation of a P(i) dataset for each protein are included.
This python script is general for either uniform or variable codon translation rates.
Sample commands to run these scripts can be found in the COMMANDS file in each protein sub-
directory.
