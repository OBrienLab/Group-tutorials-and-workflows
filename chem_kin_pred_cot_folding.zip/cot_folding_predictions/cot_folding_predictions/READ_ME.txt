This directory contains all of the input files and scripts necessary to 
calculate co-translational folding curves using Eq. 16 of the manuscript.

Sub-directories are as follows:

the_model: contains the perl script "calculate_pulse-chase_cot_folding_curve.pl"
	   to calculate co-translational folding curves using Eq. 16 of the
	   manuscript

calculate_P_i: contains a python script "calculate_P_i"  that computes the
	       values of Eq. 2 of the manuscript, which is the probability
	       of co-translational folding as a function of nascent chain
	       length. These P(i) data sets are used as an input the perl script
	       calculate_pulse-chase_cot_folding_curve.pl. The script "calculate
	       _P_iV2.1" includes additional functionality necessary to calculate
	       P(i) curves for the yeast proteins.

dhom:      contains input files and example outputs for the calculation of
	   a co-translational folding curve for the yeast protein DHOM's 
	   first domain. The translation rate and P(i) input files are in 
	   the input_files sub-directory.

dpp3:	   contains input files and example outputs for the calculation of
           a co-translational folding curve for the yeast protein DPP3's 
           second domain. The translation rate and P(i) input files are in 
           the input_files sub-directory.

ef2:	   contains input files and example outputs for the calculation of
           a co-translational folding curve for the yeast protein EF2's 
           sixth domain. The translation rate and P(i) input files are in 
           the input_files sub-directory.

sba1:	   contains input files and example outputs for the calculation of
           a co-translational folding curve for the yeast protein SBA1's 
           first domain. The translation rate and P(i) input files are in 
           the input_files sub-directory.

Each of the directories for yeast proteins contains multiple sub-directory levels
the first level down is named "fluitt_rates", because the calculations contained
within were made using codon translation rates predicted by the Fluitt-Viljoen model.
Within that directory will be two further sub-directories: the first contains the inputs
 and outputs for the slowest-translating synonymous mutant (see Results section of 
manuscript), named mut-slow. The second contains inputs and outputs for the wild-type
 transcript, and is named wt. 

sfvp_delta-c: contains input files and example outputs for the calculation
	      of a co-translational folding curve for deltc C SFVP. This 
	      directory contains subdirectories labeled "fluitt_model",
	      "fire_model", etc. that each contain calculations of co-
	      translational folding curves using the corresponding set
	      of estimated variable codon translation rates.

sfvp_wt : contains input files and example outputs for the calculation
          of a co-translational folding curve for WT C protein SFVP.
	  This directory has only one sub-directory, uniform_rates, as
          the only co-translational folding curve calculate for WT C protein
	  used a constant translation rate for every codon position in the 
	  transcript.





