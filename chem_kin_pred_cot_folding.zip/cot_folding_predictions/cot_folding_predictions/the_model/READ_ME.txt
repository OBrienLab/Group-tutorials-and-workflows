The script "calculate_pulse-chase_folding_curve.pl" computes predicted co-translational folding
curves for pulse-chase experiments. It requires as inputs a set of P(i) values (see directory calculate_P_i),
a set of translation rates, and the mRNA sequence that encodes the protein being studied.

The script requires a single command-line argument, a .cntrl file. For example. cntrl files,
see some of the sub-directories such as cot_folding_predictions/sfvp_wt/uniform_rates/pulse-chase.cntrl/
