#!/usr/bin/perl
use List::Util qw(sum);
use POSIX;

#
# Calculate a pulse chase folding curve using the O'Brien-Nissley Equation (Eq. 16)
# 
# Assumptions:
# 1. Your mRNA sequence contains a stop codon in it! If not, there will be an off-by-one problem in the predictions
#

if($#ARGV+1 != 1) #this script requires exactly 1 command-line argument
  {
  print "USAGE: perl pulse-chase.cntrl\n"; #must provide a .cntrl file; see sub-directories for examples
  die "ERROR: One command line argument required\n";
  }

# Specify your hard-coded parameters here, they may get overwritten by what is read in, in the .cntrl file
$region_of_interest = 143; # in residues; this is region we monitor in the pulse-chase experiment
$pulse_time = 45; # in seconds; time window over which new initiation events are tracked
$chase_time = 360; # in seconds; let the system evolve for this long following the pulse
$rate_of_unfolding = 4.34E-05; #bulk rate of unfolding (k_u) in units of s^-1
$rate_of_folding = 20.0; #bulk rate of folding (k_f) in units of s^-1
$incorporation_time_offset = 10; # in seconds; only strictly applicable to pulse-chase in CHO cells; see Braakman et al. 1991
$domain_start_codon = 1; #the first codon position which is a part of the monitored domain

open(IN,$ARGV[0]) or die "ERROR: Input file $ARGV[0] does not exist\n";
while(<IN>)
  {
  chomp($_);
  @dat=split(/\=/,$_);
  
  if($dat[0] =~ m/f_mrna_sequence/) {$f_mrna_sequence = $dat[1]} #load mRNA sequence specified in .cntrl file
  if($dat[0] =~ m/f_pfi/) {$f_pfi = $dat[1]} #load P(i) values calculated with Eq. 2; see directory "calculate_P_i" specified in .cntrl file
  if($dat[0] =~ m/f_codon_rates/) {$f_codon_rates = $dat[1]} #load list of codons and corresponding mean translation rates specified in .cntrl file
  if($dat[0] =~ m/region_of_interest/) {$region_of_interest = $dat[1]} #define the length of the region of interest
  if($dat[0] =~ m/rate_of_unfolding/) {$rate_of_unfolding = $dat[1]}#define the rate of unfolding in units s^-1
  if($dat[0] =~ m/rate_of_folding/) {$rate_of_folding = $dat[1]} #define the rate of folding in units of s^-1
  if($dat[0] =~ m/domain_start_codon/) {$domain_start_codon = $dat[1]} #define the starting codon of the domain
  }
close IN;
$domain_end_codon = $domain_start_codon + $region_of_interest;

# Keep a record of what parameters your calculation utilized.
open(OUT,">input_parameters_used.log");
print OUT "f_mrna_sequence=$f_mrna_sequence\n";
print OUT "f_codon_rates=$f_codon_rates\n";
print OUT "f_pfi=$f_pfi\n";
print OUT "region_of_interest=$region_of_interest\n";
print OUT "pulse_time=$pulse_time\n";
print OUT "chase_time=$chase_time\n";
print OUT "rate_of_unfolding=$rate_of_unfolding\n";
print OUT "rate_of_folding=$rate_of_folding\n";
print OUT "domain_start_codon=$domain_start_codon\n";
print OUT "incorporation_time_offset=$incorporation_time_offset\n";
close OUT;

# Read in the input files
## mRNA sequence
open(IN,"$f_mrna_sequence") or die "ERROR: $f_mrna_sequence does not exist\n";
while(<IN>)
  {
  chomp($_);
  $mRNA = $_;
  }
close IN;

## read in codon translation rates
open(IN,"$f_codon_rates") or die "ERROR: $f_codon_rates does not exist\n";
$nl=0;
while(<IN>)
  {
  $nl++;
  chomp($_);
  @dat=split(/\s+/,$_);
  $codon2rate{uc($dat[-2])}=$dat[-1]; # in units of s^-1
  $codon2time{uc($dat[-2])}=1/$dat[-1]; # in units of s
  }
close IN;

## break RNA sequence up into codons
#note well that you MUST HAVE A STOP CODON IN YOU MRNA SEQUENCE	
@nucleotides = split(//,$mRNA);
if($#nucleotides+1 % 3) 
  {
  $nl=0;
  $nc=0; # number of codons
  for($i=0;$i<=$#nucleotides;$i++)
    {
    $nl++;
    if($nl % 3 == 0)
      {
      $nc++;
      $codon = uc(join('',$nucleotides[$i-2],$nucleotides[$i-1],$nucleotides[$i]));
      $codon_seq[$nc]=$codon;
      }
    }
  }
else {die "ERROR: The RNA sequence is not an integer multiple of 3; value = $#nucleotides+1\n"} 
$nc = $nc-1; # Only do this if you've read in the stop codon. What the calculation cares about is the sense codons.
$temp = $#codon_seq;
#print "$temp is the number of codons in the sequence\n";

$minimum_codon_time = 99999;
for($i=0;$i<=$nc;$i++)
  {
  if($codon_seq[$i+1] ne "") # This array element is defined
    {
    $sfvp_translation_rate[$i]= $codon2rate{$codon_seq[$i+1]}; # We use $i+1 because this is the dwell time at nascent chain lnegth i (which sits at the P-site)
    $sfvp_translation_time[$i]= $codon2time{$codon_seq[$i+1]}; # is determined by the translation time of codon position i+1 (which sits at the A-site).
    if($sfvp_translation_time[$i] < $minimum_codon_time) {$minimum_codon_time = $sfvp_translation_time[$i] }
    } 
  }
if($minimum_codon_time == 99999) {die "ERROR: minimum_codon_time == 99999\n"}

# calculate average translation rate
for($i=1;$i<=$nc;$i++)
  {
  $sum+=$sfvp_translation_rate[$i];
  }
$avg=$sum/$nc;
#print "Average translation speed for SFVP = $avg AA/s\n";

## read in pfi
open(IN,"$f_pfi") or die "ERROR: $f_pfi does not exist\n";
$nl=0;
while(<IN>)
  {
  $nl++;
  chomp($_);
  @dat=split(/\s+/,$_);
  $pfi[1][$nl]=$nl;
  $pfi[2][$nl]=$dat[-1];
  }
close IN;
if($nl != $nc) {die "ERROR: Pfi and T_a arrays must be of the same size, $nl != $nc-1\n"}

# Calculate the steady-state populations relative to the fastest translated codon; see Eq. 10-13 of main text
for($i=1;$i<=$nc;$i++)# for each codon position
  {
  $max_N_LB[$i] = $sfvp_translation_time[$i]/$minimum_codon_time; #convert translation times into steady-state occupancies
  }
$dt =$minimum_codon_time; #integration time step, units of seconds #the fundamental time-step is the amount of time required to translate the fastest-translating codon
$total_time = $chase_time + $pulse_time; # total length of simulated experiment is pulse time + chase time
$total_steps = floor($total_time / $minimum_codon_time);
$pulse_ends =floor($pulse_time/$minimum_codon_time); #duration of the pulse in terms of number of dT points

#calculate the probability that the nascent chain segment will be folded in free solution 
$P_folding_equilibrium = $rate_of_folding/($rate_of_folding + $rate_of_unfolding); #equilibrium folding proabability is calculated solely from the underlying rates of folding and unfolding

# Setup an array to handle the time evolution of the labeled chain codon position
$array_size = 0;
for($j=1;$j<=$nc;$j++)
  {
  $boundary[$j][1] = $array_size+1; # first codon-box
  $val = ceil($max_N_LB[$j]);
  $array_size += $val;
  $boundary[$j][2] = $array_size; # last codon-box
  }
if($array_size < sum(@max_N_LB)) {die "ERROR: $array_size < sum(@max_N_LB) \n"}
      
# populate the labeled chain distribution along the CDS
# initialize, the next line is extremely important as 'unshift' doesn't work correctly without it	
for($j=0;$j<=1000000;$j++) {$population[$j]=0.0}
for($j=1;$j<=$nc;$j++)
  {
  if($max_N_LB[$j] == floor($max_N_LB[$j])) {$correct_modulous[$j]=1}
  else
    {
    $correct_modulous[$j] = $max_N_LB[$j] - floor($max_N_LB[$j]);
    } 
  for($k=1;$k<=ceil($max_N_LB[$j]);$k++)
    {
    $index = $boundary[$j][1] + $k - 1;
    $index2codon{$index} = $j;
    }
  }

# Predict P_F versus time for a pulse chase experiment
printf "#Period; Total time; Chase time; Experimental time; Total chains bound; Total chains released; P_F,t\n";
for($i=1;$i<=$total_steps;$i++) # loop over experimental time
  {
  &shift_labeled_chains_by_one_box;# see Eq. 7-9 of main text
  if($i<=$pulse_ends) # in PULSE period
    {
    &add_labeled_chains_to_codons_first_box;
    }
  &calculate_number_of_bound_labeled_chains_at_codon_j;
  &calculate_number_of_released_chains_at_time_point_i;
  &calculate_ensemble_folding_probability_at_time_point_i;  

  $time = $i*$dt; #calculate actual experimental time
  $total_chains_bound=sum(@N_LB);
  $total_chains_released=sum(@N_LR);
  $chase_time = $time - $pulse_time;
  $experimental_time_mapping = $time - $pulse_time + $incorporation_time_offset; # must account for the fact that it takes the cells
									    # an additional $incorporation_time_offset seconds for tRNA to be charged
									    # with the radiolabeled amino acids in the cytoplasm

  if($i<=$pulse_ends) {printf "PULSE:%8.1f %8.2f %8.2f %8.2f %8.9f %8.9f %12.9f\n",$i,$time,$chase_time,$experimental_time_mapping,$total_chains_bound,$total_chains_released,$P_t}
  else {printf "CHASE:%8.1f %8.2f %8.2f %8.2f %8.9f %8.9f %12.9f\n",$i, $time,$chase_time,$experimental_time_mapping,$total_chains_bound,$total_chains_released,$P_t}
  }


sub shift_labeled_chains_by_one_box
  {
  unshift(@population,'0.0'); # At each time step, shift the ribosome density down one codon-box position
  for($j=1;$j<=$nc;$j++)
    {
    $diff = $population[$boundary[$j][2]] - $correct_modulous[$j];
    if($diff > 0.000000000001)
      {
      $population[$boundary[$j][2]] -= $diff;
      if( $j+1 <= $nc) 
        {
        $population[$boundary[$j+1][1]] += $diff;
        }
      else 
        {
        $population[$boundary[$j][2]+1] += $diff;
        }

      if($population[$boundary[$j+1][1]] > 1 and $j+1 <= $nc) 
        {
        # This may be a floating point error. Try correcting it...
        $diff = $population[$boundary[$j+1][1]] - 1;
        $population[$boundary[$j+1][1]] -= $diff;
        $population[$boundary[$j][2]] += $diff;

        # If you can't correct it, then die....
        if($population[$boundary[$j+1][1]] > 1) {die "ERROR4 in assumptions, $i, $j+1, $boundary[$j+1][1], $population[$boundary[$j+1][1]], $correct_modulous[$j], $max_N_LB[$j+1]\n"}
        }
      }
    }
  }

sub add_labeled_chains_to_codons_first_box
  {
  local($j);
  for($j=$domain_start_codon;$j<=$domain_end_codon;$j++)
    {
    $population[$boundary[$j][1]] = 1;
    }
  }

sub calculate_number_of_bound_labeled_chains_at_codon_j
  {
  local($j);
  #calculate number of N_LB at codon j
  $found = 0;
  $trailing_codon = 0;
  for($j=1;$j<=$nc;$j++)
    { 
    $N_LB[$j] = 0;
    $start = $boundary[$j][1];
    $end = $boundary[$j][2];
    $val=0.0;
    for($k=$start;$k<=$end;$k++)
      {
      $val+=$population[$k];
      }

    $N_LB[$j] = $val;
    if($N_LB[$j] > 0) 
      {
      $found = 1;
      $leading_codon = $j;
      }
    if($N_LB[$j] == 0 and $found == 0) {$trailing_codon = $j+1}
    }
  }

sub calculate_number_of_released_chains_at_time_point_i
  {
  $N_LR[$i] = $population[$boundary[$nc][2]+1]; # This is the box right after the last codon-box of the c-terminal residue, i.e., this
                                                # is the number of chains release at this time step.
  }

sub calculate_ensemble_folding_probability_at_time_point_i
  {
  local($sum_pfb_nlb, $total_labeled_chains, $sum_nlr_pfr, $k);
  #total_labeled_chains is constant during the chase
  $sum_pfb_nlb=0;
  for($k=1;$k<=$nc;$k++) # Note well, the max value assumes you've read in the stop codon                  
    {
    $sum_pfb_nlb += $pfi[2][$k]*$N_LB[$k];
    }
  $sum_nlr_pfr=0;
  for($k=1;$k<=$i;$k++)
    {        
    $P_FR[$k] = ($pfi[2][$nc] - $P_folding_equilibrium)*exp(-($rate_of_folding + $rate_of_unfolding)*$minimum_codon_time*($i-$k)) + $P_folding_equilibrium;
    $sum_nlr_pfr += $P_FR[$k]*$N_LR[$k];
    }
  
  $total_labeled_chains = sum(@N_LB) + sum(@N_LR);
  if($total_labeled_chains==0) {$P_t=0}
  else {$P_t = (1/$total_labeled_chains)*($sum_pfb_nlb + $sum_nlr_pfr)} #calculate the probability of folding at this time point
  }
